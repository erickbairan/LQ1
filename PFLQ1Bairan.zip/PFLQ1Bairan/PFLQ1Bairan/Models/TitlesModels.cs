﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PFLQ1Bairan.Models
{
    public class TitlesModels
    {
        [Key]

        public int titleID { get; set; }

        [Display(Name = "Publisher")]
        [Required]
        public int pubID { get; set; }

        public List<SelectListItem> pubNames { get; set; }

        [Display(Name = "Publisher")]
        [Required]
        public string pubName { get; set; }

        [Display(Name = "Author")]
        [Required]
        public int authorID { get; set; }

        public List<SelectListItem> authorNames { get; set; }

        [Display(Name = "Author")]
        [Required]
        public string authorFN { get; set; }

        [Display(Name = " ")]
        [Required]
        public string authorLN { get; set; }

        [Display(Name = "Title Name")]
        [Required]
        [MaxLength(80)]
        public string titleName { get; set; }

        [Display(Name = "Price")]
        [Required]
        public string titlePrice { get; set; }

        [Display(Name = "Publication Date")]
        [Required]
        [DataType(DataType.Date)]
        public DateTime titlePubDate { get; set; }

        [Display(Name = "Notes")]
        [Required]
        [MaxLength(200)]
        public string titleNotes { get; set; }
    }
}